#include "physics.h"

int x_position(int x, float delt_x, struct ball* ball1)
{
  x += delt_x;
  int temp;
    if(x <= LEFT_WALL_X1)
    {
        ball1->vx = -1*ball1->vx;     //flip the velocity
        temp = LEFT_WALL_X1 - x;
        x = LEFT_WALL_X1 + temp;
    }
    else if(x >= RIGHT_WALL_X1)
      {
        ball1->vx = -1*ball1->vx;
        temp = x - RIGHT_WALL_X1;
        x = RIGHT_WALL_X1 - temp;
      }

    return x;
}

int y_position(int y, float delt_y, struct ball* ball1)
{
  y += delt_y;
  int ke;
  int temp1;
  if(y <= LEFT_WALL_Y1)
    {
      //win
    }
  else if(y >= LEFT_WALL_Y2)
    {
//      ke = 0.5 * ball1->mass * ball1->vy * ball1->vy;
//      ke = ENERGY_INCREASE * ke;
//      ball1->vy = (2*ke/ball1->mass)^(0.5);
      ball1->vy = ENERGY_DECREASE * ball1->vy;
      ball1->vy = -1*ball1->vy;

      temp1 = y - LEFT_WALL_Y2;
      y = LEFT_WALL_Y2 - temp1;
    }

  return y;
}


//int platform_position(int left, int right, int delt_x, struct platform* platform1)
//{
//  left += delt_x;
//  right += delt_x;
//
//  if(right >= )
//}
