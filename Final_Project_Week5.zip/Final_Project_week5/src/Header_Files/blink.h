/***************************************************************************//**
 * @file
 * @brief Blink examples functions
 *******************************************************************************
 * # License
 * <b>Copyright 2020 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#ifndef BLINK_H
#define BLINK_H

#include "gpio.h"
#include "capsense.h"
#include "physics.h"

#define BLINK_TASK_STACK_SIZE      96

#define BLINK_TASK_PRIO            20


#define ZERO                        0

#define BUTTON_TASK_STACK_SIZE     512
#define BUTTON_TASK_PRIO           10

#define PHYSICS_TASK_STACK_SIZE    512
#define PHYSICS_TASK_PRIO          10

#define IDLE_TASK_STACK_SIZE        512
#define IDLE_TASK_PRIO              50

#define LED_TASK_STACK_SIZE        512
#define LED_TASK_PRIO              30

#define LCD_DISPLAY_TASK_STACK_SIZE        512
#define LCD_DISPLAY_TASK_PRIO              30

#define platform_TASK_STACK_SIZE        512
#define platform_TASK_PRIO              20

#define INCREMENT     5
#define DECREMENT     -5

#define BALL_RAD     8

#define MSG_Q_SIZE                  sizeof(int)

#define GRAVITY 1.1

#define TAU_PHYSICS 3

#define TAU_LCD  3

#define LEFT_WALL_X1  10
#define LEFT_WALL_Y1  10

#define LEFT_WALL_X2  10
#define LEFT_WALL_Y2  118

#define RIGHT_WALL_X1  118
#define RIGHT_WALL_Y1  10

#define RIGHT_WALL_X2  118
#define RIGHT_WALL_Y2  118

#define ENERGY_INCREASE 1.3
#define ENERGY_DECREASE 0.9

/***************************************************************************//**
 * Initialize blink example
 ******************************************************************************/
void blink_init(void);
void read_capsense(void);

struct platform{
  unsigned x_min;
  unsigned x_max;
  unsigned y_position;
  unsigned energy;
};

struct ball{
  unsigned num_of_balls;
  unsigned diameter;
  unsigned ball_x_position;
  unsigned ball_y_position;
  unsigned mass;
  float vx;
  float vy;
};

struct shield{
  unsigned ke_reduction;
  unsigned boost;
  unsigned ke_increase;
  unsigned recharge_time;
};

#endif  // BLINK_H
